# SimpleUnlocker Remastered 4.0

Windows Forms utility, .NET 8. The project is source code; EXE is built by GitHub Actions.

## Build from Android
1. Create a GitHub repository and upload all files from this ZIP (including `.github/workflows/build.yml`).
2. Open repository → **Actions** → **Build Windows EXE** → **Run workflow**.
3. Wait for green success → open run → **Artifacts** → download `SimpleUnlockerRemastered-4.0-win-x64`.
4. Extract the artifact ZIP on Windows and run `SimpleUnlockerRemastered.exe`.

## Modules
Overview, processes, startup, services, Task Scheduler, user policy scan, Winlogon, drivers,
system information, disks, network, Defender/firewall status, SFC/DISM, restore point,
registry export, Event Viewer and action log.

## Safety
Most tabs are read-only. Process termination, service control, Winlogon edits, SFC/DISM and restore-point creation
can affect the OS; confirm carefully and use administrator rights only when necessary.
This is a diagnostic/repair helper, not an antivirus or a true file-handle unlocker.
The current source has not been compiled/tested in a Windows environment. Review before running.


## Version 4.1 changes
- Fixed doubled backslashes in C# verbatim registry paths.
- Added app.manifest requiring administrator elevation at startup (UAC prompt).
