using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.ServiceProcess;
using System.Security.Principal;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace SimpleUnlockerRemastered
{
    public class MainForm : Form
    {
        private const string WinlogonKey = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon";
        private static readonly string[] StartupKeys = { @"Software\Microsoft\Windows\CurrentVersion\Run", @"Software\Microsoft\Windows\CurrentVersion\RunOnce" };

        private TabControl tabs = new TabControl();
        private TextBox logBox;
        private System.Windows.Forms.Timer processTimer;
        private bool IsAdmin => new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);

        // LIVE
        private bool live = true;
        private bool wmiOk;
        private Label liveLabel, cpuLabel, ramLabel, eventLabel;
        private Button pauseButton;
        private ManagementEventWatcher startWatcher, stopWatcher;
        private readonly List<RegistryWatcher> regWatchers = new List<RegistryWatcher>();
        private readonly List<FileSystemWatcher> fsWatchers = new List<FileSystemWatcher>();

        // Процессы
        private ListView procList;
        private readonly Dictionary<int, ListViewItem> procItems = new Dictionary<int, ListViewItem>();
        private readonly ProcSorter procSorter = new ProcSorter();

        // Автозагрузка / Winlogon
        private ListView startupList, winlogonList;
        private System.Windows.Forms.Timer startupDebounce, winlogonDebounce;
        private HashSet<string> startupPrev;
        private Dictionary<string, string> winlogonPrev;
        private readonly Dictionary<string, string> winlogonMarks = new Dictionary<string, string>();

        private sealed class StartupEntry
        {
            public string Hive = "", Key = "", Name = "", Command = "";
            public string Id => Hive + "|" + Key + "|" + Name + "|" + Command;
        }

        public MainForm()
        {
            Text = "SimpleUnlocker Remastered 5.1 LIVE";
            Width = 1120; Height = 760; MinimumSize = new Size(900, 600);
            StartPosition = FormStartPosition.CenterScreen;

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.Controls.Add(BuildLiveBar(), 0, 0);
            tabs.Dock = DockStyle.Fill; root.Controls.Add(tabs, 0, 1);
            Controls.Add(root);

            AddInfoTab("Обзор", "SimpleUnlocker Remastered 5.1 LIVE\n\nДиагностика Windows и инструменты восстановления.\nПроцессы, автозагрузка и Winlogon отслеживаются в реальном времени.\nПо умолчанию проверки только читают данные.\nОперации изменения системы требуют подтверждения и запуска от администратора.");
            AddProcesses(); AddStartup(); AddServices(); AddTasks(); AddRestrictions(); AddWinlogon();
            AddDrivers(); AddSystemInfo(); AddDisk(); AddNetwork(); AddSecurity(); AddRepair(); AddRestorePoint(); AddRegistryBackup(); AddEventLog();
            var logTab = new TabPage("Журнал"); logBox = new TextBox { Multiline=true, ReadOnly=true, Dock=DockStyle.Fill, ScrollBars=ScrollBars.Both, Font=new Font("Consolas",9) }; logTab.Controls.Add(logBox); tabs.TabPages.Add(logTab);
            ApplyTheme();
            Log("Программа запущена. Администратор: " + IsAdmin);
            StartLive();
        }

        // ================= LIVE =================
        Control BuildLiveBar()
        {
            var bar = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Padding = new Padding(8, 4, 8, 4) };
            var bold = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            liveLabel = new Label { AutoSize = true, Font = bold, Margin = new Padding(0, 6, 18, 0), Text = "● LIVE" };
            cpuLabel = new Label { AutoSize = true, Font = bold, Margin = new Padding(0, 6, 18, 0), Text = "CPU: —" };
            ramLabel = new Label { AutoSize = true, Font = bold, Margin = new Padding(0, 6, 18, 0), Text = "RAM: —" };
            eventLabel = new Label { AutoSize = true, Margin = new Padding(0, 7, 18, 0), ForeColor = Color.DimGray, Text = "Событий пока нет" };
            pauseButton = new Button { AutoSize = true, Text = "Пауза LIVE", Padding = new Padding(6, 1, 6, 1) };
            pauseButton.Click += (s, e) => SetLive(!live);
            bar.Controls.AddRange(new Control[] { liveLabel, cpuLabel, ramLabel, eventLabel, pauseButton });
            return bar;
        }

        void StartLive()
        {
            processTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            processTimer.Tick += (s, e) => OnLiveTick();
            processTimer.Start();
            StartProcessEvents();
            StartRegistryWatchers();
            UpdateLiveLabel();
            OnLiveTick();
        }

        void StopLive()
        {
            try { processTimer?.Stop(); } catch { }
            try { startWatcher?.Stop(); startWatcher?.Dispose(); } catch { }
            try { stopWatcher?.Stop(); stopWatcher?.Dispose(); } catch { }
            foreach (var w in regWatchers) w.Dispose();
            foreach (var w in fsWatchers) { try { w.EnableRaisingEvents = false; w.Dispose(); } catch { } }
        }

        protected override void OnFormClosing(FormClosingEventArgs e) { StopLive(); base.OnFormClosing(e); }

        void UiPost(Action a) { try { if (IsHandleCreated && !IsDisposed && !Disposing) BeginInvoke(a); } catch { } }

        void SetLive(bool on)
        {
            live = on;
            processTimer.Enabled = on;
            pauseButton.Text = on ? "Пауза LIVE" : "Продолжить LIVE";
            Log("LIVE-мониторинг: " + (on ? "включён" : "на паузе"));
            if (on) { SyncProcesses(true); RefreshStartup(); RefreshWinlogon(); OnLiveTick(); }
            UpdateLiveLabel();
        }

        void UpdateLiveLabel()
        {
            if (liveLabel == null) return;
            if (!live) { liveLabel.Text = "● ПАУЗА"; liveLabel.ForeColor = Color.Gray; return; }
            bool regOk = regWatchers.Count > 0 && regWatchers.All(w => w.Active);
            if (wmiOk && regOk) { liveLabel.Text = "● LIVE"; liveLabel.ForeColor = Color.FromArgb(0, 150, 60); }
            else { liveLabel.Text = "● LIVE (частично)"; liveLabel.ForeColor = Color.DarkOrange; }
        }

        void OnLiveTick()
        {
            if (!live || IsDisposed) return;
            double cpu = SystemLoad.CpuPercent();
            cpuLabel.Text = "CPU: " + cpu.ToString("F0") + "%";
            cpuLabel.ForeColor = cpu >= 85 ? Color.DarkRed : (cpu >= 50 ? Color.DarkOrange : Color.FromArgb(0, 120, 50));
            if (SystemLoad.Memory(out var used, out var total, out var pct))
            {
                ramLabel.Text = "RAM: " + used.ToString("F1") + " / " + total.ToString("F1") + " ГБ (" + pct + "%)";
                ramLabel.ForeColor = pct >= 90 ? Color.DarkRed : (pct >= 75 ? Color.DarkOrange : Color.FromArgb(0, 120, 50));
            }
            SyncProcesses(!wmiOk);   // если WMI-события недоступны — резервный опрос с добавлением новых
            UpdateLiveLabel();
        }

        void StartProcessEvents()
        {
            try
            {
                startWatcher = new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStartTrace"));
                startWatcher.EventArrived += (s, e) =>
                {
                    int pid = Convert.ToInt32(e.NewEvent["ProcessID"]);
                    string name = Convert.ToString(e.NewEvent["ProcessName"]) ?? "";
                    UiPost(() => OnProcessStarted(pid, name));
                };
                stopWatcher = new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStopTrace"));
                stopWatcher.EventArrived += (s, e) =>
                {
                    int pid = Convert.ToInt32(e.NewEvent["ProcessID"]);
                    string name = Convert.ToString(e.NewEvent["ProcessName"]) ?? "";
                    UiPost(() => OnProcessStopped(pid, name));
                };
                startWatcher.Start(); stopWatcher.Start();
                wmiOk = true;
                Log("WMI-события запуска/завершения процессов активны.");
            }
            catch (Exception ex)
            {
                wmiOk = false;
                Log("WMI-события недоступны (" + ex.Message + "). Включён резервный опрос раз в секунду.");
            }
        }

        void StartRegistryWatchers()
        {
            foreach (var key in StartupKeys)
            {
                regWatchers.Add(new RegistryWatcher(RegistryWatcher.HKCU, key, false, ScheduleStartupRefresh));
                regWatchers.Add(new RegistryWatcher(RegistryWatcher.HKLM, key, false, ScheduleStartupRefresh));
            }
            regWatchers.Add(new RegistryWatcher(RegistryWatcher.HKLM, WinlogonKey, true, ScheduleWinlogonRefresh));
            foreach (var dir in StartupFolders())
            {
                try
                {
                    if (!Directory.Exists(dir)) continue;
                    var w = new FileSystemWatcher(dir) { NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.CreationTime };
                    FileSystemEventHandler h = (s, e) => ScheduleStartupRefresh();
                    w.Created += h; w.Deleted += h; w.Changed += h; w.Renamed += (s, e) => ScheduleStartupRefresh();
                    w.EnableRaisingEvents = true;
                    fsWatchers.Add(w);
                }
                catch (Exception ex) { Log("Не удалось следить за папкой " + dir + ": " + ex.Message); }
            }
        }

        void ScheduleStartupRefresh() => UiPost(() => { if (!live) return; startupDebounce.Stop(); startupDebounce.Start(); });
        void ScheduleWinlogonRefresh() => UiPost(() => { if (!live) return; winlogonDebounce.Stop(); winlogonDebounce.Start(); });

        static IEnumerable<string> StartupFolders()
        {
            yield return Environment.GetFolderPath(Environment.SpecialFolder.Startup);
            yield return Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup);
        }
        void ApplyTheme()
        {
            Font = new Font("Segoe UI", 9.5f);
            BackColor = Color.FromArgb(245, 247, 250);
            ForeColor = Color.FromArgb(35, 42, 52);
            tabs.Font = new Font("Segoe UI", 9.5f);
        }
        string CollectReport()
        {
            var sb = new StringBuilder();
            sb.AppendLine("SimpleUnlocker Remastered — диагностический отчёт");
            sb.AppendLine("Дата: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            sb.AppendLine("Администратор: " + IsAdmin);
            sb.AppendLine("\r\n=== SYSTEMINFO ===\r\n" + Cmd("systeminfo",30000));
            sb.AppendLine("\r\n=== PROCESS LIST ===\r\n" + Cmd("tasklist /v",30000));
            sb.AppendLine("\r\n=== SERVICES ===\r\n" + Cmd("sc query type= service state= all",30000));
            sb.AppendLine("\r\n=== STARTUP ===\r\n" + Cmd("wmic startup get caption,command,location",30000));
            sb.AppendLine("\r\n=== NETWORK ===\r\n" + Cmd("ipconfig /all",20000));
            sb.AppendLine("\r\n=== DISKS ===\r\n" + Cmd("wmic logicaldisk get caption,size,freespace",20000));
            sb.AppendLine("\r\n=== DEFENDER ===\r\n" + Cmd("powershell -NoProfile -Command \"Get-MpComputerStatus | Format-List\"",30000));
            return sb.ToString();
        }
        void AddInfoTab(string title, string text) { var p=new TabPage(title); p.Controls.Add(new Label{Text=text,Dock=DockStyle.Fill,Padding=new Padding(20),Font=new Font("Segoe UI",12)}); tabs.TabPages.Add(p); }
        TabPage NewTab(string title) { var p=new TabPage(title); tabs.TabPages.Add(p); return p; }
        void Log(string s) { if(logBox!=null) logBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {s}\r\n"); }
        void AddButton(FlowLayoutPanel f,string text,Action a) { var b=new Button{Text=text,AutoSize=true,Padding=new Padding(8)}; b.Click+=(s,e)=>{try{a();}catch(Exception ex){Log(ex.Message);MessageBox.Show(ex.Message,"Ошибка");}}; f.Controls.Add(b); }
        ListView List(TabPage p, string[] cols) { var l=new ListView{Dock=DockStyle.Fill,View=View.Details,FullRowSelect=true,GridLines=true}; foreach(var c in cols)l.Columns.Add(c, c=="Путь"||c=="Команда"||c=="Описание"?360:150); p.Controls.Add(l); return l; }
        void Run(string file,string args,bool admin=false) { var psi=new ProcessStartInfo(file,args){UseShellExecute=true,Verb=admin?"runas":""}; Process.Start(psi); Log("Запуск: "+file+" "+args); }
        string Cmd(string command,int timeout=20000) { var psi=new ProcessStartInfo("cmd.exe","/c "+command){UseShellExecute=false,RedirectStandardOutput=true,RedirectStandardError=true,CreateNoWindow=true}; using(var pr=Process.Start(psi)){string o=pr.StandardOutput.ReadToEnd(); string e=pr.StandardError.ReadToEnd(); pr.WaitForExit(timeout); return o+(string.IsNullOrWhiteSpace(e)?"":"\r\n"+e);}}
        bool Confirm(string msg)=>MessageBox.Show(msg,"Подтверждение",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes;

        // ================= ПРОЦЕССЫ =================
        void AddProcesses(){
            var p=NewTab("Процессы");
            var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);
            var l=List(p,new[]{"PID","Имя","CPU %","Память МБ","Путь"});
            l.Columns[0].Width=75;l.Columns[1].Width=190;l.Columns[2].Width=80;l.Columns[3].Width=105;l.Columns[4].Width=500;
            l.BringToFront();f.BringToFront();
            procList=l;
            l.ColumnClick+=(s,e)=>{
                if(e.Column==procSorter.Column)procSorter.Descending=!procSorter.Descending;
                else{procSorter.Column=e.Column;procSorter.Descending=(e.Column==2||e.Column==3);}
                SortProcs();
            };
            AddButton(f,"Обновить вручную",()=>SyncProcesses(true));
            AddButton(f,"Открыть расположение",()=>{if(l.SelectedItems.Count>0){var path=l.SelectedItems[0].SubItems[4].Text;if(File.Exists(path))Run("explorer.exe","/select,\""+path+"\"");}});
            AddButton(f,"Завершить процесс",()=>{if(l.SelectedItems.Count>0&&Confirm("Принудительно завершить выбранный процесс?")){var pid=l.SelectedItems[0].Text;Process.GetProcessById(int.Parse(pid)).Kill();Log("Завершён PID "+pid);}});
            SyncProcesses(true);
        }

        void SortProcs(){
            if(procList==null)return;
            procList.ListViewItemSorter=procSorter;procList.Sort();procList.ListViewItemSorter=null;
        }

        ListViewItem CreateProcItem(Process x){
            string path="";try{path=x.MainModule?.FileName??"";}catch{}
            var it=new ListViewItem(x.Id.ToString()){Tag=new ProcState()};
            it.SubItems.Add(x.ProcessName);it.SubItems.Add("0.0");it.SubItems.Add("0.0");it.SubItems.Add(path);
            procItems[x.Id]=it;procList.Items.Add(it);
            return it;
        }

        void UpdateProcItem(ListViewItem it,Process x,DateTime now){
            var st=(ProcState)it.Tag!;
            st.MemMb=SafeMemory(x)/1048576.0;
            try{
                var cpu=x.TotalProcessorTime;
                if(st.LastTime!=default){
                    double dt=(now-st.LastTime).TotalSeconds;
                    if(dt>0)st.Cpu=Math.Clamp((cpu-st.LastCpu).TotalSeconds/(dt*Environment.ProcessorCount)*100.0,0,100);
                }
                st.LastCpu=cpu;st.LastTime=now;
            }catch{st.Cpu=0;}
            string cs=st.Cpu.ToString("F1"),ms=st.MemMb.ToString("F1");
            if(it.SubItems[2].Text!=cs)it.SubItems[2].Text=cs;
            if(it.SubItems[3].Text!=ms)it.SubItems[3].Text=ms;
            bool system=IsLikelySystem(x.ProcessName)&&st.MemMb<250;
            bool heavy=st.MemMb>=500;
            bool busy=st.Cpu>=50;
            it.BackColor=heavy?Color.FromArgb(255,220,220):(busy?Color.FromArgb(255,238,205):(system?Color.FromArgb(218,245,225):Color.White));
            it.ForeColor=heavy?Color.DarkRed:(busy?Color.DarkOrange:(system?Color.DarkGreen:Color.FromArgb(35,42,52)));
        }

        void RemoveProc(int pid){
            if(procItems.TryGetValue(pid,out var it)){procItems.Remove(pid);procList.Items.Remove(it);}
        }

        // Полная сверка + обновление CPU/RAM. addMissing=true добавляет процессы, пропущенные событиями.
        void SyncProcesses(bool addMissing){
            if(procList==null||IsDisposed)return;
            var now=DateTime.UtcNow;
            var procs=Process.GetProcesses();
            var alive=new HashSet<int>();
            procList.BeginUpdate();
            try{
                foreach(var x in procs){
                    try{
                        alive.Add(x.Id);
                        if(!procItems.TryGetValue(x.Id,out var it)){if(!addMissing)continue;it=CreateProcItem(x);}
                        UpdateProcItem(it,x,now);
                    }catch{}
                    finally{x.Dispose();}
                }
                foreach(var pid in procItems.Keys.Where(k=>!alive.Contains(k)).ToList())RemoveProc(pid);
                SortProcs();
            }finally{procList.EndUpdate();}
        }

        void OnProcessStarted(int pid,string name){
            if(!live||procList==null)return;
            eventLabel.Text="＋ "+name+" (PID "+pid+") "+DateTime.Now.ToString("HH:mm:ss");
            try{
                using(var x=Process.GetProcessById(pid)){
                    if(procItems.ContainsKey(pid))return;
                    var it=CreateProcItem(x);UpdateProcItem(it,x,DateTime.UtcNow);
                }
                procList.BeginUpdate();try{SortProcs();}finally{procList.EndUpdate();}
            }catch{}
        }

        void OnProcessStopped(int pid,string name){
            if(!live||procList==null)return;
            eventLabel.Text="－ "+name+" (PID "+pid+") "+DateTime.Now.ToString("HH:mm:ss");
            RemoveProc(pid);
        }
        long SafeMemory(Process p){try{return p.WorkingSet64;}catch{return 0;}}
        bool IsLikelySystem(string name){return new[]{"System","Idle","svchost","csrss","wininit","winlogon","services","lsass","smss","explorer"}.Contains(name,StringComparer.OrdinalIgnoreCase);}
        // ================= АВТОЗАГРУЗКА =================
        List<StartupEntry> ReadStartup(){
            var res=new List<StartupEntry>();
            foreach(var pair in new[]{(Registry.CurrentUser,"HKCU"),(Registry.LocalMachine,"HKLM")})
                foreach(var key in StartupKeys)
                    try{
                        using(var k=pair.Item1.OpenSubKey(key)){
                            if(k==null)continue;
                            foreach(var n in k.GetValueNames())res.Add(new StartupEntry{Hive=pair.Item2,Key=key,Name=n,Command=Convert.ToString(k.GetValue(n))??""});
                        }
                    }catch{}
            foreach(var dir in StartupFolders())
                try{
                    if(!Directory.Exists(dir))continue;
                    foreach(var file in Directory.GetFiles(dir)){
                        var fn=Path.GetFileName(file);
                        if(fn.Equals("desktop.ini",StringComparison.OrdinalIgnoreCase))continue;
                        res.Add(new StartupEntry{Hive="FOLDER",Key=dir,Name=fn,Command=file});
                    }
                }catch{}
            return res;
        }

        static bool IsSuspiciousStartup(StartupEntry e){
            string c=e.Command.ToLowerInvariant();
            if(e.Hive=="FOLDER"){string ext=Path.GetExtension(c);return new[]{".vbs",".js",".ps1",".cmd",".bat",".wsf"}.Contains(ext);}
            return c.Contains("\\temp\\")||c.Contains("\\appdata\\")||c.Contains("powershell -")||c.Contains("wscript");
        }

        void RefreshStartup(){
            if(startupList==null)return;
            var entries=ReadStartup();
            var ids=new HashSet<string>(entries.Select(x=>x.Id));
            if(startupPrev!=null){
                foreach(var e in entries)if(!startupPrev.Contains(e.Id))Log("Автозагрузка: добавлено ["+e.Hive+"] "+e.Name+" → "+e.Command);
                foreach(var id in startupPrev)if(!ids.Contains(id))Log("Автозагрузка: удалено "+id);
            }
            startupPrev=ids;
            var selected=startupList.SelectedItems.Count>0?startupList.SelectedItems[0].Tag as string:null;
            startupList.BeginUpdate();
            try{
                startupList.Items.Clear();
                foreach(var e in entries){
                    var it=new ListViewItem(e.Hive){Tag=e.Id};
                    it.SubItems.Add(e.Key);it.SubItems.Add(e.Name);it.SubItems.Add(e.Command);
                    bool sus=IsSuspiciousStartup(e);
                    it.BackColor=sus?Color.FromArgb(255,225,225):Color.FromArgb(225,245,230);
                    it.ForeColor=sus?Color.DarkRed:Color.DarkGreen;
                    startupList.Items.Add(it);
                    if(selected==e.Id)it.Selected=true;
                }
            }finally{startupList.EndUpdate();}
        }

        void AddStartup(){
            var p=NewTab("Автозагрузка");
            var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);
            var l=List(p,new[]{"Hive","Раздел","Имя","Команда"});
            l.Columns[0].Width=80;l.Columns[1].Width=330;l.Columns[2].Width=180;l.Columns[3].Width=450;
            l.BringToFront();f.BringToFront();startupList=l;
            startupDebounce=new System.Windows.Forms.Timer{Interval=400};
            startupDebounce.Tick+=(s,e)=>{startupDebounce.Stop();RefreshStartup();};
            AddButton(f,"Обновить вручную",RefreshStartup);
            AddButton(f,"Удалить запись",()=>{
                if(l.SelectedItems.Count==0||!Confirm("Удалить выбранную запись автозагрузки?"))return;
                var i=l.SelectedItems[0];
                if(i.Text=="FOLDER"){File.Delete(i.SubItems[3].Text);}
                else{
                    var root=i.Text=="HKCU"?Registry.CurrentUser:Registry.LocalMachine;
                    using(var k=root.OpenSubKey(i.SubItems[1].Text,true)){k?.DeleteValue(i.SubItems[2].Text,false);}
                }
                Log("Удалена запись автозагрузки: "+i.SubItems[2].Text);RefreshStartup();
            });
            AddButton(f,"Открыть папку Startup",()=>Run("explorer.exe","shell:startup"));
            RefreshStartup();
        }
        void AddServices(){var p=NewTab("Службы");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var l=List(p,new[]{"Имя","Статус","Тип запуска","Описание"});l.BringToFront();f.BringToFront();Action refresh=()=>{l.Items.Clear();foreach(var s in System.ServiceProcess.ServiceController.GetServices().OrderBy(x=>x.ServiceName)){string status=s.Status.ToString(),start="",desc="";try{using(var k=Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\"+s.ServiceName)){start=Convert.ToString(k?.GetValue("Start"));desc=Convert.ToString(k?.GetValue("Description"));}}catch{}var it=new ListViewItem(s.ServiceName);it.SubItems.Add(status);it.SubItems.Add(start);it.SubItems.Add(desc);l.Items.Add(it);}};AddButton(f,"Обновить",refresh);AddButton(f,"Открыть services.msc",()=>Run("services.msc",""));AddButton(f,"Остановить службу",()=>{if(l.SelectedItems.Count>0&&Confirm("Остановить службу? Это может нарушить работу Windows."))Run("sc.exe","stop "+l.SelectedItems[0].Text,true);});AddButton(f,"Запустить службу",()=>{if(l.SelectedItems.Count>0&&Confirm("Запустить службу?"))Run("sc.exe","start "+l.SelectedItems[0].Text,true);});refresh();}
        void AddTasks(){var p=NewTab("Планировщик");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both,Font=new Font("Consolas",9)};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Список задач",()=>{t.Text=Cmd("schtasks /query /fo LIST /v",30000);Log("Просмотр задач");});AddButton(f,"Открыть планировщик",()=>Run("taskschd.msc",""));}
        void AddRestrictions(){var p=NewTab("Политики");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var l=List(p,new[]{"Область","Параметр","Значение"});l.BringToFront();f.BringToFront();string[] keys={"DisableTaskMgr","DisableRegistryTools","NoControlPanel","DisableCMD","NoDrives","DisallowRun"};Action refresh=()=>{l.Items.Clear();foreach(var n in keys)try{using(var k=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System")){var v=k?.GetValue(n);var it=new ListViewItem("HKCU Policies\\System");it.SubItems.Add(n);it.SubItems.Add(v==null?"не задан":v.ToString());l.Items.Add(it);}}catch{}};AddButton(f,"Проверить",refresh);AddButton(f,"Открыть редактор групповых политик",()=>Run("gpedit.msc",""));AddButton(f,"Экспорт отчёта",()=>{var s=string.Join(Environment.NewLine,l.Items.Cast<ListViewItem>().Select(x=>x.Text+" | "+x.SubItems[1].Text+" | "+x.SubItems[2].Text));using(var d=new SaveFileDialog{Filter="TXT|*.txt",FileName="policies.txt"})if(d.ShowDialog()==DialogResult.OK)File.WriteAllText(d.FileName,s);});refresh();}
        // ================= WINLOGON =================
        static string FmtReg(object v){
            if(v==null)return "";
            if(v is byte[] b)return BitConverter.ToString(b);
            if(v is string[] sa)return string.Join(" ; ",sa);
            return Convert.ToString(v)??"";
        }

        void RefreshWinlogon(){
            if(winlogonList==null)return;
            var cur=new Dictionary<string,string>();
            try{
                using(var k=Registry.LocalMachine.OpenSubKey(WinlogonKey)){
                    if(k!=null){
                        foreach(var n in k.GetValueNames())cur[n==""?"(по умолчанию)":n]=FmtReg(k.GetValue(n));
                        foreach(var sub in k.GetSubKeyNames())cur["[ПОДКЛЮЧ] "+sub]="Открыть regedit для просмотра";
                    }
                }
            }catch(Exception ex){Log("Winlogon: "+ex.Message);}
            if(winlogonPrev!=null){
                string stamp="ИЗМЕНЕНО "+DateTime.Now.ToString("HH:mm:ss");
                foreach(var kv in cur){
                    if(!winlogonPrev.TryGetValue(kv.Key,out var old)){Log("Winlogon: добавлен параметр "+kv.Key+" = "+kv.Value);winlogonMarks[kv.Key]="ДОБАВЛЕНО "+DateTime.Now.ToString("HH:mm:ss");}
                    else if(old!=kv.Value){Log("Winlogon: "+kv.Key+": '"+old+"' → '"+kv.Value+"'");winlogonMarks[kv.Key]=stamp;}
                }
                foreach(var kv in winlogonPrev)if(!cur.ContainsKey(kv.Key))Log("Winlogon: удалён параметр "+kv.Key+" (было '"+kv.Value+"')");
            }
            winlogonPrev=cur;
            winlogonList.BeginUpdate();
            try{
                winlogonList.Items.Clear();
                foreach(var kv in cur){
                    var it=new ListViewItem(kv.Key);it.SubItems.Add(kv.Value);
                    winlogonMarks.TryGetValue(kv.Key,out var mark);it.SubItems.Add(mark??"");
                    bool bad=(kv.Key=="Shell"&&!kv.Value.Equals("explorer.exe",StringComparison.OrdinalIgnoreCase))
                          ||(kv.Key=="Userinit"&&!kv.Value.EndsWith("userinit.exe,",StringComparison.OrdinalIgnoreCase));
                    if(bad){it.BackColor=Color.FromArgb(255,225,225);it.ForeColor=Color.DarkRed;}
                    else if(mark!=null){it.BackColor=Color.FromArgb(255,245,200);}
                    else if(kv.Key.StartsWith("[ПОДКЛЮЧ]"))it.BackColor=Color.FromArgb(225,235,250);
                    winlogonList.Items.Add(it);
                }
            }finally{winlogonList.EndUpdate();}
        }

        void AddWinlogon(){
            var p=NewTab("Winlogon");
            var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);
            var l=List(p,new[]{"Параметр","Значение","Статус"});
            l.Columns[0].Width=220;l.Columns[1].Width=520;l.Columns[2].Width=180;
            l.BringToFront();f.BringToFront();winlogonList=l;
            winlogonDebounce=new System.Windows.Forms.Timer{Interval=300};
            winlogonDebounce.Tick+=(s,e)=>{winlogonDebounce.Stop();RefreshWinlogon();};
            AddButton(f,"Обновить вручную",RefreshWinlogon);
            AddButton(f,"Восстановить Shell/Userinit",()=>{
                if(!IsAdmin){MessageBox.Show("Нужны права администратора.");return;}
                if(!Confirm("Восстановить стандартные Shell и Userinit?"))return;
                using(var k=Registry.LocalMachine.OpenSubKey(WinlogonKey,true)){
                    k.SetValue("Shell","explorer.exe");
                    k.SetValue("Userinit",Environment.GetFolderPath(Environment.SpecialFolder.Windows)+@"\system32\userinit.exe,");
                }
                Log("Winlogon восстановлен");RefreshWinlogon();
            });
            RefreshWinlogon();
        }
        void AddDrivers(){var p=NewTab("Драйверы");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both,Font=new Font("Consolas",9)};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Список драйверов",()=>t.Text=Cmd("driverquery /v /fo table",30000));AddButton(f,"Открыть диспетчер устройств",()=>Run("devmgmt.msc",""));}
        void AddSystemInfo(){var p=NewTab("Система");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Собрать сведения",()=>t.Text=Cmd("systeminfo",30000)+"\r\n\r\n"+Cmd("wmic cpu get name")+"\r\n"+Cmd("wmic path win32_videocontroller get name")+"\r\n"+Cmd("wmic logicaldisk get caption,size,freespace"));AddButton(f,"Диспетчер задач",()=>Run("taskmgr.exe",""));}
        void AddDisk(){var p=NewTab("Диски");var l=List(p,new[]{"Диск","Файловая система","Всего ГБ","Свободно ГБ"});foreach(var d in DriveInfo.GetDrives())try{if(d.IsReady){var it=new ListViewItem(d.Name);it.SubItems.Add(d.DriveFormat);it.SubItems.Add((d.TotalSize/1073741824.0).ToString("F1"));it.SubItems.Add((d.AvailableFreeSpace/1073741824.0).ToString("F1"));l.Items.Add(it);}}catch{}}
        void AddNetwork(){var p=NewTab("Сеть");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"IP-конфигурация",()=>t.Text=Cmd("ipconfig /all"));AddButton(f,"Сетевые соединения",()=>t.Text=Cmd("netstat -ano"));AddButton(f,"Открыть настройки сети",()=>Run("ms-settings:network",""));}
        void AddSecurity(){var p=NewTab("Безопасность");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Статус Defender",()=>t.Text=Cmd("powershell -NoProfile -Command \"Get-MpComputerStatus | Format-List\""));AddButton(f,"Брандмауэр",()=>t.Text=Cmd("netsh advfirewall show allprofiles"));AddButton(f,"Открыть безопасность Windows",()=>Run("windowsdefender:",""));}
        void AddRepair(){var p=NewTab("Восстановление");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"SFC /scannow",()=>{if(Confirm("Запустить проверку системных файлов?"))Run("cmd.exe","/k sfc /scannow",true);});AddButton(f,"DISM RestoreHealth",()=>{if(Confirm("Запустить восстановление образа Windows?"))Run("cmd.exe","/k DISM /Online /Cleanup-Image /RestoreHealth",true);});AddButton(f,"Проверка DISM",()=>Run("cmd.exe","/k DISM /Online /Cleanup-Image /CheckHealth",true));}
        void AddRestorePoint(){var p=NewTab("Точка восстановления");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Создать точку",()=>{if(!IsAdmin){MessageBox.Show("Запустите программу от администратора.");return;}if(Confirm("Создать точку восстановления системы?"))Run("powershell.exe","-NoProfile -Command \"Checkpoint-Computer -Description 'SimpleUnlocker backup' -RestorePointType 'MODIFY_SETTINGS'\"",true);});AddButton(f,"Открыть восстановление",()=>Run("rstrui.exe",""));}
        void AddRegistryBackup(){var p=NewTab("Резерв реестра");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Экспорт ветки Winlogon",()=>{using(var d=new SaveFileDialog{Filter="REG|*.reg",FileName="Winlogon_backup.reg"})if(d.ShowDialog()==DialogResult.OK)Run("reg.exe","export \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\" \""+d.FileName+"\" /y",true);});AddButton(f,"Экспорт Policies",()=>{using(var d=new SaveFileDialog{Filter="REG|*.reg",FileName="Policies_backup.reg"})if(d.ShowDialog()==DialogResult.OK)Run("reg.exe","export \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\" \""+d.FileName+"\" /y");});AddButton(f,"Открыть regedit",()=>Run("regedit.exe",""));}
        void AddEventLog(){var p=NewTab("Журнал событий");var f=new FlowLayoutPanel{Dock=DockStyle.Top,AutoSize=true};p.Controls.Add(f);var t=new TextBox{Dock=DockStyle.Fill,Multiline=true,ScrollBars=ScrollBars.Both,Font=new Font("Consolas",9)};p.Controls.Add(t);t.BringToFront();f.BringToFront();AddButton(f,"Последние системные ошибки",()=>t.Text=Cmd("powershell -NoProfile -Command \"Get-WinEvent -LogName System -MaxEvents 40 | Format-Table TimeCreated,Id,LevelDisplayName,Message -Wrap\""));AddButton(f,"Открыть eventvwr",()=>Run("eventvwr.msc",""));}
    }
}
