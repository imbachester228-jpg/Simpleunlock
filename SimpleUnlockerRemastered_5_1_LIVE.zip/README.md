# SimpleUnlocker Remastered 5.1 LIVE

Windows Forms utility, .NET 8. The project is source code; EXE is built by GitHub Actions.

## Build from Android
1. Create a GitHub repository and upload all files from this ZIP (including `.github/workflows/build.yml`).
2. Open repository → **Actions** → **Build Windows EXE** → **Run workflow**.
3. Wait for green success → open run → **Artifacts** → download `SimpleUnlockerRemastered-5.1-LIVE-win-x64`.
4. Extract the artifact ZIP on Windows and run `SimpleUnlockerRemastered.exe`.

## Modules
Overview, processes, startup, services, Task Scheduler, user policy scan, Winlogon, drivers,
system information, disks, network, Defender/firewall status, SFC/DISM, restore point,
registry export, Event Viewer and action log.

## Safety
Most tabs are read-only. Process termination, service control, Winlogon edits, SFC/DISM and restore-point creation
can affect the OS; confirm carefully and use administrator rights only when necessary.
This is a diagnostic/repair helper, not an antivirus or a true file-handle unlocker.
The current source has not been compiled/tested in a Windows environment. Review before running.


## Version 4.1 changes
- Fixed doubled backslashes in C# verbatim registry paths.
- Added app.manifest requiring administrator elevation at startup (UAC prompt).


## Version 5.0 UI updates
- Winlogon tab now lists all values and subkeys automatically (read-only enumeration).
- Startup entries auto-refresh every 5 seconds, with green normal entries and red heuristic flags (AppData/Temp, PowerShell, WScript).
- Process auto-refresh and memory color indicators retained.
- Includes automatic diagnostic report export.


## Version 5.1 LIVE
- Processes: event-based detection of start/stop via WMI (`Win32_ProcessStartTrace` / `Win32_ProcessStopTrace`) instead of a 3-second refresh. If WMI is unavailable, a 1-second polling fallback is used automatically.
- CPU % per process added; CPU/RAM values (per process and system-wide in the top bar) update once per second. Click a column header to sort.
- Startup: Run/RunOnce (HKCU + HKLM) tracked with registry change notifications (`RegNotifyChangeKeyValue`); the user/common Startup folders are tracked with `FileSystemWatcher`. Additions/removals are written to the log.
- Winlogon: the whole key (with subkeys) is watched; changed values are logged and highlighted with a timestamp; non-default Shell/Userinit are shown in red.
- LIVE indicator in the top bar: green `LIVE`, orange `LIVE (частично)` if some watcher is not active, grey `ПАУЗА`. The "Пауза LIVE" button pauses/resumes everything.
- "Обновить вручную" button kept in the Processes, Startup and Winlogon tabs.
- Fixed C# string escaping in the "Открыть расположение" and Defender-status commands and in the report headers.
- Added `.github/workflows/build.yml` and the `System.Management` package.
- Note: there is no universal event for every startup source (Services, Scheduled Tasks, WMI subscriptions etc. are not watched).
- The source has not been compiled in this environment (no .NET SDK); build via GitHub Actions and report any compiler errors.
